export class Task {
	/**
	 * @type {string}
	 */
	#id;

	/**
	 * @type {string}
	 */
	#title;

	/**
	 * @type {boolean}
	 */
	#completed;

	/**
	 * @type {Date}
	 */
	#createdAt;

	/**
	 * @param {string} title (titre de la tâche)
	 * @param {string | undefined} id (identifiant de la tâche)
	 * @param {boolean | undefined} completed (état de complétion de la tâche)
	 * @param {Date | undefined} createdAt (date de création de la tâche)
	 */
	constructor(
		title,
		id = crypto.randomUUID(),
		completed = false,
		createdAt = new Date(),
	) {
		if (typeof title !== "string" || title.trim() === "") {
			throw new Error("Le titre doit être une chaîne de caractères non vide.");
		}

		this.#id = id;
		this.#title = title.trim();
		this.#completed = completed;
		this.#createdAt = createdAt;
	}

	/**
	 * Retourne l'identifiant de la tâche.
	 * @returns {string}
	 */
	get id() {
		return this.#id;
	}

	/**
	 * Retourne le titre de la tâche.
	 * @returns {string}
	 */
	get title() {
		return this.#title;
	}

	/**
	 * Retourne si la tâche est complétée.
	 * @returns {boolean}
	 */
	get completed() {
		return this.#completed;
	}

	/**
	 * Retourne la date de création de la tâche.
	 * @returns {Date}
	 */
	get createdAt() {
		return this.#createdAt;
	}

	// ? Méthodes métier
	/**
	 * Inverse l'état de complétion de la tâche.
	 */
	toggle() {
		this.#completed = !this.#completed;
	}

	/**
	 * Met à jour le titre de la tâche.
	 * @param {string} title
	 */
	updateTitle(title) {
		if (typeof title !== "string" || title.trim() === "") {
			throw new Error("Le titre doit être une chaîne de caractères non vide.");
		}

		this.#title = title.trim();
	}

	/**
	 * Retourne la tâche sous forme de JSON.
	 * @returns {{id: string, title: string, completed: boolean, createdAt: Date}}
	 * @override
	 */
	toJSON() {
		return {
			id: this.id,
			title: this.title,
			completed: this.completed,
			createdAt: this.createdAt,
		};
	}

	/**
	 * Crée une tâche à partir d'un JSON.
	 * @param {{id: string, title: string, completed: boolean, createdAt: Date}} json (JSON contenant les données de la tâche)
	 * @returns {Task}
	 */
	static fromJSON(json) {
		return new Task(json.title, json.id, json.completed, json.createdAt);
	}
}
