import "./style.css";

import { TaskController } from "./controllers/TaskController.js";

// Initialisation de l'application
document.addEventListener("DOMContentLoaded", () => {
	const app = new TaskController();

	// Exposer l'app globalement pour le debug (en développement uniquement)
	if (import.meta.env.MODE === "development") {
		window.app = app;
	}

	console.log("Application initialisée");
});
