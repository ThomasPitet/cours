export class TaskStatsView {
	/**
	 * @type {HTMLElement}
	 */
	#containerElement;

	/**
	 * @param {string} containerSelector (sélecteur de l'élément de conteneur)
	 */
	constructor(containerSelector) {
		this.#containerElement = document.querySelector(containerSelector);

		if (!this.#containerElement) {
			throw new Error("Élément de conteneur non trouvé");
		}
	}

	/**
	 * Rendu des statistiques.
	 * @param {{total: number, completed: number, active: number, completionRate: number}} stats (statistiques de la liste de tâches)
	 */
	render(stats) {
		this.#containerElement.innerHTML = "";

		const statsElement = document.createElement("div");
		statsElement.classList.add("grid", "stats-grid");

		const sections = [
			{ title: "Total", value: stats.total },
			{ title: "Complétées", value: stats.completed },
			{ title: "En cours", value: stats.active },
			{ title: "Progression", value: stats.completionRate.toFixed(2) },
		];

		statsElement.append(
			...sections.map((section) => {
				const sectionElement = document.createElement("div");
				sectionElement.classList.add("card", "stats-grid-card");

				const sectionTitleElement = document.createElement("span");
				sectionTitleElement.textContent = section.title;
				sectionTitleElement.classList.add("stats-grid-card-title");

				const sectionValueElement = document.createElement("span");
				sectionValueElement.textContent = section.value;
				sectionValueElement.classList.add("stats-grid-card-value");

				sectionElement.append(sectionTitleElement, sectionValueElement);

				return sectionElement;
			}),
		);

		this.#updateProgressBar(stats.completionRate);
	}

	/**
	 * Met à jour la barre de progression.
	 * @param {number} completionRate (pourcentage de complétion)
	 */
	#updateProgressBar(completionRate) {
		const progressBarElement = document.createElement("div");
		progressBarElement.classList.add("progress-bar");

		const progressBarValueElement = document.createElement("span");
		progressBarValueElement.textContent = `${completionRate}%`;
		progressBarValueElement.style.width = `${completionRate}%`;
		progressBarValueElement.classList.add("progress-bar-value");

		progressBarElement.appendChild(progressBarValueElement);
		this.#containerElement.appendChild(progressBarElement);
	}

	/**
	 * Masque les statistiques.
	 */
	hide() {
		this.#containerElement.classList.add("hidden");
	}

	/**
	 * Affiche les statistiques.
	 */
	show() {
		this.#containerElement.classList.remove("hidden");
	}
}
