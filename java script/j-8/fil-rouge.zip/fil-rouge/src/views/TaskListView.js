export class TaskListView {
	/**
	 * @type {HTMLElement} (élément de conteneur)
	 */
	#containerElement;

	/**
	 * @type {Function} (fonction de rappel pour le toggle)
	 */
	#toggleCallback;

	/**
	 * @type {Function} (fonction de rappel pour la suppression)
	 */
	#deleteCallback;

	/**
	 * @type {Function} (fonction de rappel pour l'édition)
	 */
	#editCallback;

	/**
	 * @param {string} containerSelector (sélecteur de l'élément de conteneur)
	 */
	constructor(containerSelector) {
		this.#containerElement = document.querySelector(containerSelector);

		if (!this.#containerElement) {
			throw new Error("Élément de conteneur non trouvé");
		}
	}

	/**
	 * Définit la fonction de rappel pour le toggle.
	 * @param {Function} callback (fonction de rappel)
	 */
	onToggle(callback) {
		this.#toggleCallback = callback;
	}

	/**
	 * Définit la fonction de rappel pour la suppression.
	 * @param {Function} callback (fonction de rappel)
	 */
	onDelete(callback) {
		this.#deleteCallback = callback;
	}

	/**
	 * Définit la fonction de rappel pour l'édition.
	 * @param {Function} callback (fonction de rappel)
	 */
	onEdit(callback) {
		this.#editCallback = callback;
	}

	/**
	 * Rendu de la liste de tâches.
	 * @param {Task[]} tasks (liste d'instances de tâches)
	 */
	render(tasks) {
		// ? On vide le conteneur
		this.#containerElement.innerHTML = "";

		if (tasks.length === 0) {
			this.#renderEmptyState();
			return;
		}

		this.#containerElement.append(
			...tasks.map((task) => {
				return this.#createTaskElement(task);
			}),
		);
	}

	/**
	 * Rendu de l'état vide (liste de tâches vide).
	 */
	#renderEmptyState() {
		const emptyStateElement = document.createElement("li");
		emptyStateElement.classList.add("empty-state");

		const emptyStateTitle = document.createElement("p");
		emptyStateTitle.textContent = "Aucune tâche pour le moment.";

		const emptyStateDescription = document.createElement("p");
		emptyStateDescription.textContent = "Ajoutez une tâche pour commencer.";
		emptyStateDescription.classList.add("hint");

		emptyStateElement.append(emptyStateTitle, emptyStateDescription);
		this.#containerElement.appendChild(emptyStateElement);
	}

	/**
	 * Crée un élément de tâche.
	 * @param {Task} task (instance de la tâche)
	 * @returns {HTMLLIElement} (élément de tâche)
	 */
	#createTaskElement(task) {
		const taskElement = document.createElement("li");
		taskElement.classList.add("task");

		// ? Création de l'élément de titre (span)
		const taskTitleElement = document.createElement("span");
		taskTitleElement.textContent = task.title;
		taskTitleElement.classList.add("task-title");
		taskTitleElement.dataset.taskId = task.id;

		// ? Création de l'élément de toggle (checkbox)
		const taskToggleElement = document.createElement("input");
		taskToggleElement.setAttribute("type", "checkbox");
		taskToggleElement.classList.add("task-toggle");
		taskToggleElement.addEventListener("change", () => {
			if (typeof this.#toggleCallback === "function") {
				this.#toggleCallback(task.id);
			}
		});

		const taskActionsElement = document.createElement("div");
		taskActionsElement.classList.add("task-actions");

		// ? Création de l'élément de suppression (button)
		const taskDeleteElement = document.createElement("button");
		taskDeleteElement.classList.add("button", "button--danger");
		taskDeleteElement.setAttribute("type", "button");
		taskDeleteElement.textContent = "Supprimer";
		taskDeleteElement.addEventListener("click", () => {
			if (typeof this.#deleteCallback === "function") {
				this.#deleteCallback(task.id);
			}
		});

		// ? Création de l'élément d'édition (button)
		const taskEditElement = document.createElement("button");
		taskEditElement.classList.add("button", "button--primary");
		taskEditElement.setAttribute("type", "button");
		taskEditElement.textContent = "Éditer";
		taskEditElement.addEventListener("click", () => {
			if (typeof this.#editCallback === "function") {
				this.#editCallback(task.id, task.title);
			}
		});

		// ? Ajout des éléments d'actions à l'élément des actions
		taskActionsElement.append(taskDeleteElement, taskEditElement);

		// ? Si la tâche est complétée, on ajoute la classe task--completed et on coche la checkbox
		if (task.completed) {
			taskElement.classList.add("task--completed");
			taskToggleElement.setAttribute("checked", "checked");
		}

		// ? Ajout des éléments à l'élément de la tâche
		taskElement.append(taskTitleElement, taskToggleElement, taskActionsElement);

		return taskElement;
	}
}
