/**
 * Vue du formulaire de création de tâche.
 */
export class TaskFormView {
	/**
	 * @type {HTMLFormElement}
	 */
	#formElement;

	/**
	 * @type {HTMLInputElement}
	 */
	#inputElement;

	/**
	 * @type {Function}
	 * @description Fonction de rappel pour la soumission du formulaire.
	 */
	#submitCallback;

	/**
	 * @param {string} formSelector (sélecteur du formulaire)
	 * @param {string} inputSelector (sélecteur du champ de saisie)
	 */
	constructor(formSelector, inputSelector) {
		this.#formElement = document.querySelector(formSelector);
		this.#inputElement = document.querySelector(inputSelector);

		if (!this.#formElement || !this.#inputElement) {
			throw new Error("Formulaire ou champ de saisie non trouvé");
		}

		this.#setupEventListeners();
	}

	/**
	 * Configure les événements du formulaire.
	 */
	#setupEventListeners() {
		this.#formElement.addEventListener("submit", (event) => {
			event.preventDefault();
			const title = this.getTitle();

			// ? Si le titre est valide et que la fonction de rappel est définie...
			if (title && typeof this.#submitCallback === "function") {
				// ? ... on appelle la fonction de rappel...
				this.#submitCallback(title);

				// ? ... et on vide le champ de saisie
				this.clear();
			}
		});
	}

	/**
	 * Définit la fonction de rappel pour la soumission du formulaire.
	 * @param {Function} callback (fonction de rappel)
	 */
	onSubmit(callback) {
		this.#submitCallback = callback;
	}

	/**
	 * Récupère le titre du formulaire.
	 * @returns {string} (titre du formulaire)
	 */
	getTitle() {
		return this.#inputElement.value.trim();
	}

	/**
	 * Vide le champ de saisie.
	 */
	clear() {
		this.#inputElement.value = ""; // ? On vide le champ de saisie
		this.#inputElement.focus(); // ? On récupère le focus sur le champ de saisie
	}

	/**
	 * Désactive le champ de saisie.
	 */
	disable() {
		this.#inputElement.setAttribute("disabled", "disabled");
	}

	/**
	 * Active le champ de saisie.
	 */
	enable() {
		this.#inputElement.removeAttribute("disabled");
	}

	/**
	 * Affiche un message d'erreur.
	 * @param {string} message (message d'erreur)
	 */
	showError(message) {
		const errorElement = document.createElement("p");
		errorElement.classList.add("error-message");
		errorElement.textContent = message;
		this.#formElement.appendChild(errorElement);

		setTimeout(() => {
			// ? On supprime l'élément d'erreur après 5 secondes
			errorElement.remove();
		}, 5000);
	}
}
