import { Task } from "../models/Task.js";
import { EventEmitter } from "../utils/EventEmitter.js";

/**
 * Gestionnaire de listes de tâches.
 */
export class TaskManager extends EventEmitter {
	/**
	 * @type {Task[]}
	 */
	#tasks;

	constructor() {
		super();
		this.#tasks = [];
	}

	// ? Opérations CRUD
	/**
	 * @param {string} taskTitle (titre de la tâche)
	 * @returns {Task} (instance de la tâche ajoutée)
	 */
	add(taskTitle) {
		const newTask = new Task(taskTitle);
		this.#tasks.push(newTask);
		this.emit("task:added", { task: newTask });
		this.emit("tasks:changed", { tasks: this.getAll() });

		return newTask;
	}

	/**
	 * @param {string} taskId (identifiant de la tâche à supprimer)
	 * @returns {boolean} (true si la tâche a été supprimée, false sinon)
	 */
	remove(taskId) {
		// ? On cherche l'index de la tâche à supprimer
		const taskIndex = this.#tasks.findIndex((task) => task.id === taskId);

		// ? Si la tâche existe, on la supprime et on notifie les observateurs
		if (taskIndex !== -1) {
			const removedTask = this.#tasks[taskIndex];
			this.#tasks.splice(taskIndex, 1);
			this.emit("task:removed", { task: removedTask });
			this.emit("tasks:changed", { tasks: this.getAll() });

			return true;
		}

		return false;
	}

	/**
	 * @param {string} taskId (identifiant de la tâche à inverser)
	 * @returns {boolean} (true si la tâche a été inversée, false sinon)
	 */
	toggle(taskId) {
		const taskIndex = this.#tasks.findIndex((task) => task.id === taskId);

		if (taskIndex !== -1) {
			this.#tasks[taskIndex].toggle();
			this.emit("task:toggled", { task: this.getById(taskId) });
			this.emit("tasks:changed", { tasks: this.getAll() });

			return true;
		}

		return false;
	}

	/**
	 * Met à jour le titre d'une tâche.
	 * @param {string} taskId (identifiant de la tâche à mettre à jour)
	 * @param {string} newTitle (nouveau titre de la tâche)
	 * @returns {boolean} (true si la tâche a été mise à jour, false sinon)
	 */
	update(taskId, newTitle) {
		const task = this.getById(taskId);

		if (task) {
			task.updateTitle(newTitle);
			this.emit("task:updated", { task });
			this.emit("tasks:changed", { tasks: this.getAll() });

			return true;
		}

		return false;
	}

	// ? Requêtes (queries)
	/**
	 * Récupère une tâche par son identifiant.
	 * @param {string} taskId (identifiant de la tâche à récupérer)
	 * @returns {Task | undefined} (instance de la tâche si trouvée, undefined sinon)
	 */
	getById(taskId) {
		return this.#tasks.find((task) => task.id === taskId);
	}

	/**
	 * Récupère toutes les tâches.
	 * @returns {Task[]} (liste des tâches)
	 */
	getAll() {
		// ? On retourne une copie profonde des tâches pour éviter les modifications directes sur la liste
		return this.#tasks.map((task) => task.toJSON());
	}

	/**
	 * Récupère toutes les tâches complétées.
	 * @returns {Task[]} (liste des tâches complétées)
	 */
	getCompleted() {
		return this.#tasks.filter((task) => task.completed);
	}

	/**
	 * Récupère toutes les tâches actives.
	 * @returns {Task[]} (liste des tâches actives)
	 */
	getActive() {
		return this.#tasks.filter((task) => !task.completed);
	}

	// ? Logiques métier
	/**
	 * Récupère les statistiques de la liste de tâches.
	 * @returns {{total: number, completed: number, active: number, completionRate: number}}
	 */
	getStats() {
		return {
			total: this.#tasks.length,
			completed: this.getCompleted().length,
			active: this.getActive().length,
			completionRate:
				this.#tasks.length > 0
					? Math.round((this.getCompleted().length / this.#tasks.length) * 100)
					: 0,
		};
	}

	// ? Gestion des données (locale)
	/**
	 * Retourne les tâches sous forme de JSON.
	 * @returns {string} (JSON contenant les tâches)
	 */
	toJSON() {
		return this.#tasks.map((task) => task.toJSON());
	}

	/**
	 * Charge les tâches depuis un JSON.
	 * @param {{id: string, title: string, completed: boolean, createdAt: Date}[]} jsonTasks (JSON contenant les tâches)
	 */
	loadFromJSON(jsonTasks) {
		this.#tasks = jsonTasks.map((jsonTask) => Task.fromJSON(jsonTask));
		this.emit("task:loaded", { tasks: this.getAll() });
		this.emit("tasks:changed", { tasks: this.getAll() });
	}

	/**
	 * Vide la liste de tâches.
	 */
	clear() {
		this.#tasks = [];
		this.emit("task:cleared", null);
		this.emit("tasks:changed", { tasks: this.getAll() });
	}
}
